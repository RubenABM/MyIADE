package com.example.myiade;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.VIBRATE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myiade.downloadtasks.JSONObj;
import com.example.myiade.downloadtasks.JSONObjToArray;
import com.example.myiade.downloadtasks.PresenceQRPOST;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import eu.livotov.labs.android.camview.ScannerLiveView;
import eu.livotov.labs.android.camview.scanner.decoder.zxing.ZXDecoder;

public class Presence extends AppCompatActivity {

    DrawerLayout drawerLayout;
    JSONObject loginjson = null, sched_id = null;
    TextView username;
    TextView useremail, item;
    ImageView icon;
    LinearLayout layout;
    static String iduser, schedule_id;
    private ScannerLiveView camera;
    private TextView scanned;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presence);
        drawerLayout =findViewById(R.id.drawer_layout);
        username = findViewById(R.id.usernameview);
        useremail = findViewById(R.id.useremailview);
        iduser = getIntent().getStringExtra("key");

        item = findViewById(R.id.pre_view);
        icon = findViewById(R.id.pre_icon);
        layout = findViewById(R.id.pre_layout);
        layout.setBackgroundResource(R.drawable.menu_item_perso);
        item.setTextColor(ContextCompat.getColor(this,R.color.UE_Red));
        icon.setColorFilter(ContextCompat.getColor(this,R.color.UE_Red), android.graphics.PorterDuff.Mode.MULTIPLY);

        JSONObj task = new JSONObj();
        try {
            loginjson = task.execute("https://myiade.herokuapp.com/api/students/"+iduser).get();
            username.setText(loginjson.getString("name"));
            useremail.setText(loginjson.getString("email"));
        } catch (ExecutionException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (JSONException e) {
            e.printStackTrace();
        }


        if (checkPermission()) {
            Toast.makeText(this, "Permission Granted..", Toast.LENGTH_SHORT).show();
        } else {
            requestPermission();
        }

        scanned = findViewById(R.id.dadosScanner);
        camera = (ScannerLiveView) findViewById(R.id.camview);



        camera.setScannerViewEventListener(new ScannerLiveView.ScannerViewEventListener() {
            @Override
            public void onScannerStarted(ScannerLiveView scanner) {
                Toast.makeText(Presence.this, "A Iniciar Scan", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onScannerStopped(ScannerLiveView scanner) {
                Toast.makeText(Presence.this, "A parar Scan", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onScannerError(Throwable err) {
                Toast.makeText(Presence.this, "Erro de Scan: " + err.getMessage(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeScanned(String data) {



                JSONObjToArray task1 = new JSONObjToArray();
                try {
                    sched_id = task1.execute("https://myiade.herokuapp.com/api/presences/scheduleid/"+data).get();
                    schedule_id = sched_id.getString("scheduleID");



                    Map<String, String> postData = new HashMap<>();
                    postData.put("presenceStudentID", iduser);
                    postData.put("presenceScheduleID", schedule_id);

                    PresenceQRPOST task2 = new PresenceQRPOST(postData);
                    task2.execute("https://myiade.herokuapp.com//api/presences/"+iduser+"/"+schedule_id);

                } catch (ExecutionException e) {
                    e.printStackTrace();
                    sched_id = null;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    sched_id = null;
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                scanned.setText(schedule_id);

            }
        });


    }

    public void ClickMenu(View view) {

        Index.openDrawer(drawerLayout);

    }

    public void ClickLogo(View view) {

        Index.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view) {

        Index.redirectActivity(this, Index.class);

    }

    public void ClickCourse(View view) {
        Index.redirectActivity(this, Course.class);
    }

    public void ClickCampus(View view) {
        Index.redirectActivity(this, Campus.class);
    }

    public void ClickPresence(View view) {Index.closeDrawer(drawerLayout); }

    public void ClickProfile(View view) {
        Index.redirectActivity(this, Profile.class);
    }

    public void ClickLogout(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Terminar Sessão");

        builder.setMessage("Têm a ceteza que pertende terminar a sua sessão?");

        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                logout();
            }
        });

        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();

    }

    public void logout(){

        Intent myIntent = new Intent(this, MainActivity.class);
        myIntent.putExtra("key", iduser);
        this.startActivity(myIntent);

    }

    public  void ClickEmail(View view){

        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://portal.office365.com/"));
        startActivity(viewIntent);
    }

    private boolean checkPermission() {
        int camera_permission = ContextCompat.checkSelfPermission(getApplicationContext(), CAMERA);
        int vibrate_permission = ContextCompat.checkSelfPermission(getApplicationContext(), VIBRATE);
        return camera_permission == PackageManager.PERMISSION_GRANTED && vibrate_permission == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        int PERMISSION_REQUEST_CODE = 200;
        ActivityCompat.requestPermissions(this, new String[]{CAMERA, VIBRATE}, PERMISSION_REQUEST_CODE);
    }


    @Override
    protected void onResume() {
        super.onResume();
        ZXDecoder decoder = new ZXDecoder();
        // 0.5 is the area where we have
        // to place red marker for scanning.
        decoder.setScanAreaPercent(0.8);
        camera.setDecoder(decoder);
        camera.startScanner();
    }

    @Override
    protected void onPause() {

        super.onPause();
        camera.stopScanner();
        Index.closeDrawer(drawerLayout);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0) {
            boolean cameraaccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
            boolean vibrateaccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
            if (cameraaccepted && vibrateaccepted) {
                Toast.makeText(this, "Permission granted..", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denined \n You cannot use app without providing permission", Toast.LENGTH_SHORT).show();
            }
        }
    }
}