package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.myiade.downloadtasks.JSONObj;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class Index extends AppCompatActivity {

    DrawerLayout drawerLayout;
    JSONObject loginjson = null;
    TextView username, useremail, home_item;
    ImageView home_icon;
    static String iduser;
    LinearLayout home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);
        drawerLayout =findViewById(R.id.drawer_layout);
        username = findViewById(R.id.usernameview);
        useremail = findViewById(R.id.useremailview);
        home_item = findViewById(R.id.menuview_item);
        home_icon = findViewById(R.id.menuicon_item);
        home = findViewById(R.id.layout_home);
        home.setBackgroundResource(R.drawable.menu_item_perso);
        home_item.setTextColor(ContextCompat.getColor(this,R.color.UE_Red));
        home_icon.setColorFilter(ContextCompat.getColor(this,R.color.UE_Red), android.graphics.PorterDuff.Mode.MULTIPLY);
        iduser = getIntent().getStringExtra("key");
        JSONObj task = new JSONObj();
        try {
            loginjson = task.execute("https://myiade.herokuapp.com/api/students/"+iduser).get();

            username.setText(loginjson.getString("name"));
            useremail.setText(loginjson.getString("email"));



        } catch (ExecutionException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public void ClickMenu(View view){

        openDrawer(drawerLayout);

    }

    public static void openDrawer(DrawerLayout drawerLayout) {

        drawerLayout.openDrawer(GravityCompat.START);
        
    }
    
    public void ClickLogo(View view){
        
        closeDrawer(drawerLayout);
        
    }

    public static void closeDrawer(DrawerLayout drawerLayout) {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }

    }




    public  void ClickHome(View view){ closeDrawer(drawerLayout); }

    public  void ClickCourse( View view) {
        redirectActivity(this, Course.class);
    }

    public void  ClickCampus(View view){
        redirectActivity(this,Campus.class);
    }

    public void  ClickPresence(View view){
        redirectActivity(this,Presence.class);
    }

    public void  ClickProfile(View view){
        redirectActivity(this,Profile.class);
    }

    public  void ClickEmail(View view){

        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://portal.office365.com/"));
        startActivity(viewIntent);
    }

    public void logout(){

        Intent myIntent = new Intent(this, MainActivity.class);
        myIntent.putExtra("key", iduser);
        this.startActivity(myIntent);

    }

      public void ClickLogout(View view) {

          AlertDialog.Builder builder = new AlertDialog.Builder(this);

          builder.setTitle("Terminar Sessão");

          builder.setMessage("Têm a ceteza que pertende terminar a sua sessão?");

          builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {

                  logout();

              }
          });

          builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
              }
          });

          builder.show();

    }

    public static void redirectActivity(Activity activity, Class aClass) {

        Intent intent = new Intent(activity, aClass);
        intent.putExtra("key",iduser);

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);

    }

    public void ClickPub1(View view){
        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://www.iade.europeia.pt/noticias#iade-finalista-no-concurso-playstation-talents"));
        startActivity(viewIntent);
    }

    public void ClickPubRitz(View view){
        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://www.iade.europeia.pt/noticias#inaugurada-exposicao-de-projeto-de-professora-do-iade"));
        startActivity(viewIntent);
    }

    public void ClickPub2(View view){
        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://www.iade.europeia.pt/noticias#livro-com-design-de-professor-do-iade-no-image-photo-festival-2021"));
        startActivity(viewIntent);
    }
    public void ClickPub3(View view){
        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://www.iade.europeia.pt/noticias#professor-do-iade-lanca-livro-dedicado-ao-neoliberalismo"));
        startActivity(viewIntent);
    }

    public void ClickPub4(View view){
        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://www.iade.europeia.pt/noticias#estudantes-do-iade-vencem-mop-digital-challenge"));
        startActivity(viewIntent);
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onPause() {

        super.onPause();
        overridePendingTransition(0, 0);
        closeDrawer(drawerLayout);
    }
}