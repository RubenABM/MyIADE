package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myiade.downloadtasks.JSONArr;
import com.example.myiade.downloadtasks.JSONObjToArray;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class presences extends AppCompatActivity {


    JSONObject loginjson = null;
    org.json.JSONArray precenseJson = null;
    TextView coursename;
    static String iduser;
    ListView MyPresence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presences);

        iduser = getIntent().getStringExtra("key");
        coursename = findViewById(R.id.textView_semester_b);
        coursename = findViewById(R.id.textView_semester_b);
        MyPresence = findViewById(R.id.Presences_listview);
        JSONObjToArray task = new JSONObjToArray();
        JSONArr task1 = new JSONArr();
        try {
            loginjson = task.execute("https://myiade.herokuapp.com/api/courses/studentscourse/" + iduser).get();
            precenseJson = task1.execute("https://myiade.herokuapp.com/api/students/presence/"+iduser).get();

            ArrayList<String> myItems = new ArrayList<String>();

            for (int i = 0; i < precenseJson.length(); i++) {

                JSONObject jsonPart = precenseJson.getJSONObject(i);
                myItems.add("Data: " + jsonPart.getString("presenceDate") + "\n\t" + jsonPart.getString("unitName") + ";");


            }
            ArrayAdapter<String> myListAdapter = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    myItems

            );

            MyPresence.setAdapter(myListAdapter);


            coursename.setText(loginjson.getString("courseName"));
        } catch (InterruptedException | ExecutionException | JSONException e) {
            e.printStackTrace();
        }

    }


    public void exitPresence(View view) {
        Intent intent = new Intent(this, Course.class);
        intent.putExtra("key", iduser);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(intent);

    }

}