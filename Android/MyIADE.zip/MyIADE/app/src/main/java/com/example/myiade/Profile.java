package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myiade.downloadtasks.JSONObj;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class Profile extends AppCompatActivity {

    DrawerLayout drawerLayout;
    JSONObject loginjson = null;
    TextView username;
    static String iduser;
    TextView useremail, userbdate, userphone, usernameitem, usernameemail, useraddress, usercivilnum, item;
    ImageView icon;
    LinearLayout layout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        drawerLayout =findViewById(R.id.drawer_layout);
        username = findViewById(R.id.usernameview);
        useremail = findViewById(R.id.useremailview);
        usernameemail = findViewById(R.id.textView_email);
        usernameitem = findViewById(R.id.textView_username);
        userbdate = findViewById(R.id.textView_bdate);
        userphone = findViewById(R.id.textView_cellphone);
        useraddress = findViewById(R.id.textView_address);
        usercivilnum = findViewById(R.id.textView_civilnum);

        item = findViewById(R.id.profile_view);
        icon = findViewById(R.id.profile_icon);
        layout = findViewById(R.id.profile_layout);
        layout.setBackgroundResource(R.drawable.menu_item_perso);
        item.setTextColor(ContextCompat.getColor(this,R.color.UE_Red));
        icon.setColorFilter(ContextCompat.getColor(this,R.color.UE_Red), android.graphics.PorterDuff.Mode.MULTIPLY);


        iduser = getIntent().getStringExtra("key");
        JSONObj task = new JSONObj();
        try {
            loginjson = task.execute("https://myiade.herokuapp.com/api/students/"+iduser).get();
            username.setText(loginjson.getString("name"));
            useremail.setText(loginjson.getString("email"));

            usernameitem.setText(loginjson.getString("name"));
            usernameemail.setText(loginjson.getString("email"));
            userbdate.setText(loginjson.getString("bdate"));
            usercivilnum.setText(loginjson.getString("civilNumber"));
            userphone.setText(loginjson.getString("phone"));
            useraddress.setText(loginjson.getString("address"));

        } catch (ExecutionException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
            loginjson = null;
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void ClickMenu(View view){

        Index.openDrawer(drawerLayout);

    }

    public void ClickLogo(View view){

        Index.closeDrawer(drawerLayout);

    }

    public  void ClickHome(View view){

        Index.redirectActivity(this, Index.class);

    }

    public  void ClickCourse( View view) {
        Index.redirectActivity(this, Course.class);
    }

    public void  ClickCampus(View view){
        Index.redirectActivity(this,Campus.class);
    }

    public void  ClickPresence(View view){
        Index.redirectActivity(this,Presence.class);
    }

    public void  ClickProfile(View view){
        Index.closeDrawer(drawerLayout);
    }

    public void ClickLogout(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Terminar Sessão");

        builder.setMessage("Têm a ceteza que pertende terminar a sua sessão?");

        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                logout();
            }
        });

        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();

    }

    public void logout(){

        Intent myIntent = new Intent(this, MainActivity.class);
        myIntent.putExtra("key", iduser);
        this.startActivity(myIntent);

    }

    public  void ClickEmail(View view){

        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://portal.office365.com/"));
        startActivity(viewIntent);
    }

    @Override
    protected void onPause() {

        super.onPause();

        Index.closeDrawer(drawerLayout);
    }

}