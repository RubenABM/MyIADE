package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myiade.downloadtasks.JSONArr;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Activity_Schedule extends AppCompatActivity {

    org.json.JSONArray jsonArray= null;
    static String iduser;
    ListView monday, tuesday, wednesday, thursday, friday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        iduser = getIntent().getStringExtra("key");

        monday = findViewById(R.id.monday_listview);
        tuesday = findViewById(R.id.tuesday_listview);
        wednesday = findViewById(R.id.listview_wednesday);
        thursday = findViewById(R.id.listview_Thursday);
        friday = findViewById(R.id.listview_friday);

        JSONArr task = new JSONArr();

        ArrayList<String> myMonday = new ArrayList<String>();
        ArrayList<String> mytuesday = new ArrayList<String>();
        ArrayList<String> mywednesday = new ArrayList<String>();
        ArrayList<String> mythursday = new ArrayList<String>();
        ArrayList<String> myfriday = new ArrayList<String>();


        try {
            jsonArray = task.execute("https://myiade.herokuapp.com/api/students/schedule/1/5").get();

            for(int i=0;i<jsonArray.length();i++) {

                JSONObject jsonPart = jsonArray.getJSONObject(i);
                if (jsonPart.getString("weekDay").equals("Segunda")){
                    myMonday.add(""+jsonPart.getString("unitName")+"\n\t"+jsonPart.getString("startTime") + " - " + jsonPart.getString("endTime")+";");
                }else if (jsonPart.getString("weekDay").equals("Terça")){
                    mytuesday.add(""+jsonPart.getString("unitName")+"\n\t"+jsonPart.getString("startTime") + " - " + jsonPart.getString("endTime")+";");
                }else if (jsonPart.getString("weekDay").equals("Quarta")){
                    mywednesday.add(""+jsonPart.getString("unitName")+"\n\t"+jsonPart.getString("startTime") + " - " + jsonPart.getString("endTime")+";");
                }else if (jsonPart.getString("weekDay").equals("Quinta")){
                    mythursday.add(""+jsonPart.getString("unitName")+"\n\t"+jsonPart.getString("startTime") + " - " + jsonPart.getString("endTime")+";");
                }else if (jsonPart.getString("weekDay").equals("Sexta")){
                    myfriday.add(""+jsonPart.getString("unitName")+"\n\t"+jsonPart.getString("startTime") + " - " + jsonPart.getString("endTime")+";");
                }

            }

            ArrayAdapter<String> myListAdaptermonday = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    myMonday

            );
            monday.setAdapter(myListAdaptermonday);

            ArrayAdapter<String> myListAdaptertuesday = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    mytuesday

            );
            tuesday.setAdapter(myListAdaptertuesday);

            ArrayAdapter<String> myListAdapterwednesday = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    mywednesday

            );
            wednesday.setAdapter(myListAdapterwednesday);

            ArrayAdapter<String> myListAdapterthursday = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    mythursday

            );
            thursday.setAdapter(myListAdapterthursday);

            ArrayAdapter<String> myListAdapterfriday = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    myfriday

            );
            friday.setAdapter(myListAdapterfriday);



        } catch (InterruptedException | ExecutionException | JSONException e) {
            e.printStackTrace();
        }

    }

    public void exitSchedules(View view){


        Intent intent = new Intent(this, Course.class);
        intent.putExtra("key",iduser);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(intent);

    }

}