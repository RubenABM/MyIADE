package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.myiade.downloadtasks.JSONObj;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    EditText editTextemail, editTextPass;
    ImageView logo;
    ProgressBar progbar;
    JSONObject loginjson = null;
    private Button button_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextemail = findViewById(R.id.editTextEmail_id);
        editTextPass = findViewById(R.id.editTextTextPassword);
        button_login = findViewById(R.id.button_login);
        progbar = findViewById(R.id.progressBar);
        logo = findViewById(R.id.imageView_logo);

        editTextPass.setVisibility(View.VISIBLE);
        editTextemail.setVisibility(View.VISIBLE);
        button_login.setVisibility(View.VISIBLE);
        logo.setVisibility(View.VISIBLE);
        progbar.setVisibility(View.INVISIBLE);



    }

    public  void onClick(View v) {

                editTextPass.setVisibility(View.INVISIBLE);
                editTextemail.setVisibility(View.INVISIBLE);
                button_login.setVisibility(View.INVISIBLE);
                logo.setVisibility(View.INVISIBLE);
                progbar.setVisibility(View.VISIBLE);


                JSONObj task = new JSONObj();
                try {
                    loginjson = task.execute("https://myiade.herokuapp.com/api/students/login/" + editTextemail.getText().toString() + "/" + editTextPass.getText().toString()).get();


                    if (loginjson != null) {
                        Toast.makeText(this, "BEM VINDO " + loginjson.getString("name") + " !!", Toast.LENGTH_SHORT).show();
                        Intent myIntent = new Intent(MainActivity.this, Index.class);
                        myIntent.putExtra("key", loginjson.getString("id"));
                        this.startActivity(myIntent);
                    } else {
                        editTextPass.setVisibility(View.VISIBLE);
                        editTextemail.setVisibility(View.VISIBLE);
                        button_login.setVisibility(View.VISIBLE);
                        logo.setVisibility(View.VISIBLE);
                        progbar.setVisibility(View.INVISIBLE);
                        editTextPass.setText("");
                        editTextemail.setText("");
                        Toast.makeText(this, "Os dados inseridos estão incorretos!!", Toast.LENGTH_LONG).show();
                    }


                } catch (ExecutionException e) {
                    e.printStackTrace();
                    loginjson = null;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    loginjson = null;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
    }
}