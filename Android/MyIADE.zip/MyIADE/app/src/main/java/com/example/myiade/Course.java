package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.myiade.downloadtasks.JSONArr;
import com.example.myiade.downloadtasks.JSONObjToArray;
import com.example.myiade.downloadtasks.JSONObj;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class Course extends AppCompatActivity {

    DrawerLayout drawerLayout;
    TextView item;
    TextView username, useremail;
    ImageView icon;
    LinearLayout layout;
    static String iduser, urldrive;
    JSONObject loginjson = null, userjson = null, driveurl= null;
    TextView coursename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        drawerLayout =findViewById(R.id.drawer_layout);
        iduser = getIntent().getStringExtra("key");

        username = findViewById(R.id.usernameview);
        useremail = findViewById(R.id.useremailview);

        item = findViewById(R.id.cour_view);
        icon = findViewById(R.id.cour_icon);
        layout = findViewById(R.id.cour_layout);
        layout.setBackgroundResource(R.drawable.menu_item_perso);
        item.setTextColor(ContextCompat.getColor(this,R.color.UE_Red));
        icon.setColorFilter(ContextCompat.getColor(this,R.color.UE_Red), android.graphics.PorterDuff.Mode.MULTIPLY);

        coursename = findViewById(R.id.textView_coursename_course);

        JSONObjToArray task = new JSONObjToArray();
        JSONObj task1 = new JSONObj();
        JSONObjToArray task2 = new JSONObjToArray();


        try {
            loginjson = task.execute("https://myiade.herokuapp.com/api/courses/studentscourse/"+iduser).get();
            coursename.setText(loginjson.getString("courseName"));

            userjson = task1.execute("https://myiade.herokuapp.com/api/students/"+iduser).get();
            username.setText(userjson.getString("name"));
            useremail.setText(userjson.getString("email"));

            driveurl = task2.execute("https://myiade.herokuapp.com/api/students/resource/"+iduser).get();
            urldrive = driveurl.getString("courseUrl");


        } catch (InterruptedException | ExecutionException | JSONException e) {
            e.printStackTrace();
        }

    }

    public void ClickMenu(View view) {

        Index.openDrawer(drawerLayout);

    }

    public void ClickLogo(View view) {

        Index.closeDrawer(drawerLayout);

    }

    public void ClickHome(View view) {

        Index.redirectActivity(this, Index.class);

    }

    public void ClickCourse(View view) {
        Index.closeDrawer(drawerLayout);
    }

    public void ClickCampus(View view) {
        Index.redirectActivity(this, Campus.class);
    }

    public void ClickPresence(View view) {
        Index.redirectActivity(this, Presence.class);
    }

    public void ClickProfile(View view) {
        Index.redirectActivity(this, Profile.class);
    }

    public void ClickLogout(View view) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Terminar Sessão");

        builder.setMessage("Têm a ceteza que pertende terminar a sua sessão?");

        builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                logout();
            }
        });

        builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();

    }

    public void logout(){

        Intent myIntent = new Intent(this, MainActivity.class);
        myIntent.putExtra("key", iduser);
        this.startActivity(myIntent);

    }

    public void ClickCalendar(View view){
        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://f.hubspotusercontent30.net/hubfs/339034/Portal%20de%20Estudante/O%20meu%20curso/CAE/IADE_UE_2020-21.pdf"));
        startActivity(viewIntent);
    }

    public void ClickResources(View view){
                    Intent viewIntent =
                    new Intent("android.intent.action.VIEW",
                            Uri.parse(urldrive));
            startActivity(viewIntent);
    }

    public  void ClickEmail(View view){

        Intent viewIntent =
                new Intent("android.intent.action.VIEW",
                        Uri.parse("https://portal.office365.com/"));
        startActivity(viewIntent);
    }

    @Override
    protected void onPause() {

        super.onPause();

        Index.closeDrawer(drawerLayout);
    }

    public void gradesClick(View view) {

        Intent intent = new Intent(this, Grades.class);
        intent.putExtra("key",iduser);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(intent);

    }

    public void schedulesClick(View view) {

        Intent intent = new Intent(this, Activity_Schedule.class);
        intent.putExtra("key",iduser);
        this.startActivity(intent);

    }

    public void ClickPresenceS(View view) {

        Intent intent = new Intent(this, presences.class);
        intent.putExtra("key",iduser);
        this.startActivity(intent);

    }
}