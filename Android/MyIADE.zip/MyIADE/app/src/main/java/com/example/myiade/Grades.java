package com.example.myiade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.myiade.downloadtasks.JSONArr;
import com.example.myiade.downloadtasks.JSONObjToArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Grades extends AppCompatActivity {

    JSONObject loginjson = null;
    org.json.JSONArray gradesJson= null, semestreJson=null;
    TextView semestera, semesterb;
    static String iduser;
    ListView MyGradesa, MyGradesb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grades);

        iduser = getIntent().getStringExtra("key");
        MyGradesa = findViewById(R.id.grades_listview_a);
        MyGradesb = findViewById(R.id.grades_listview_b);
        semestera= findViewById(R.id.textView_semester_a);
        semesterb= findViewById(R.id.textView_semester_b);

        JSONObjToArray task = new JSONObjToArray();
        JSONArr task1 = new JSONArr();
        JSONArr task2 = new JSONArr();
        try {
            loginjson = task.execute("https://myiade.herokuapp.com/api/courses/studentscourse/"+iduser).get();
            gradesJson = task1.execute("https://myiade.herokuapp.com/api/students/grades/"+iduser).get();
            semestreJson = task2.execute("https://myiade.herokuapp.com/api/students/semester/"+iduser).get();
            

            ArrayList<String> myItemsa = new ArrayList<String>();
            ArrayList<String> myItemsb = new ArrayList<String>();
            
            JSONObject jsonPart1, jsonPart2a, jsonPart2b;

            jsonPart2a= semestreJson.getJSONObject(0);
            semestera.setText("Semestre: "+jsonPart2a.getString("studentSemester"));
            jsonPart2b= semestreJson.getJSONObject(1);
            semesterb.setText("Semestre: "+jsonPart2b.getString("studentSemester"));

            for(int i=0;i<gradesJson.length();i++) {
                jsonPart1 = gradesJson.getJSONObject(i);

                if (jsonPart1.getString("unitSemester").equals(jsonPart2a.getString("studentSemester"))) {
                    myItemsa.add("\n\t" + jsonPart1.getString("unitName") + " - " + jsonPart1.getString("studentGrade") + ";");
                }else if (jsonPart1.getString("unitSemester").equals(jsonPart2b.getString("studentSemester"))){
                    myItemsb.add("\n\t" + jsonPart1.getString("unitName") + " - " + jsonPart1.getString("studentGrade") + ";");
                }

            }
            ArrayAdapter<String> myListAdaptera = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    myItemsa

            );

            ArrayAdapter<String> myListAdapterb = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    myItemsb

            );

            MyGradesa.setAdapter(myListAdaptera);
            MyGradesb.setAdapter(myListAdapterb);


        } catch (InterruptedException | ExecutionException | JSONException e) {
            e.printStackTrace();
        }

    }


    public void exitGrades(View view){


        Intent intent = new Intent(this, Course.class);
        intent.putExtra("key",iduser);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        this.startActivity(intent);

    }
}